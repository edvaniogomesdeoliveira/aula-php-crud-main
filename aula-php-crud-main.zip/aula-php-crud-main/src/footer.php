 
<div class="mt-5 p-3 border bg-light">   
<strong>DESAFIO DO DIA 💪 </strong><br>
✅ Verificar se as informações estão sendo salvas corretamente no banco de dados.<br>
⚙️ Caso não estejam, identificar e corrigir o erro.<br>
📋 Deixar a listagem dinâmica, exibindo os dados diretamente do banco, 
deixar em destaques produtos com estoque abaixo de 50.<br>
🧩 Próximo passo: implementar a funcionalidade de update (atualização de produtos) no sistema.
</div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>