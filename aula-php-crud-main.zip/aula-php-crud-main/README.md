DESAFIO DO DIA 💪 <br>
✅ Verificar se as informações estão sendo salvas corretamente no banco de dados. <br>
⚙️ Caso não estejam, identificar e corrigir o erro. <br>
📋 Deixar a listagem dinâmica, exibindo os dados diretamente do banco, deixar em destaques produtos com estoque abaixo de 50.<br>
🧩 Próximo passo: implementar a funcionalidade de update (atualização de produtos) no sistema. 
